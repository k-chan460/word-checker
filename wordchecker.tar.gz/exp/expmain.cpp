// expmain.cpp
//
// ICS 46 Winter 2019
// Project #3: Set the Controls for the Heart of the Sun
//
// Do whatever you'd like here.  This is intended to allow you to experiment
// with your code, outside of the context of the broader program or Google
// Test.
#include <string>
#include <vector>
#include <gtest/gtest.h>
#include "HashSet.hpp"


int main()
{
	HashSet<int> s1{0};
    s1.add(11);
    s1.add(1);
    s1.add(5);

	// std::cout << s1.contains(11) << std::endl;    
	std::cout << "hello" << std::endl;
    return 0;
}

